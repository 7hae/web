<?php
	global $wpdb;
	$start=$_POST['start'];
	$offset=$_POST['offset'];
	echo $start.'-'.$offset;
?>